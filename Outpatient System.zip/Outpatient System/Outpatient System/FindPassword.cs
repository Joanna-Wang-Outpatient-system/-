﻿using System.Data;
using System;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Outpatient_System
{
    public partial class FindPassword : Form
    {
        public FindPassword()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void Btn_Authentication_Click(object sender, EventArgs e)
        {
            SqlConnection sqlConnection = new SqlConnection();
            sqlConnection.ConnectionString =
                "Server=(local);Database=OutpatientSystem;Integrated Security=sspi";
            SqlCommand sqlCommand = new SqlCommand();
            sqlCommand.Connection = sqlConnection;
            sqlCommand.CommandText =
                $"SELECT* FROM tb_Authentication WHERE IDNumber=@IDNumber; ";
            sqlCommand.Parameters.AddWithValue("@IDNumber", this.Tex_IDNumber.Text.Trim());
            sqlConnection.Open();
            SqlDataReader sqlDataReader= sqlCommand.ExecuteReader();
            if (sqlDataReader.Read())
            {
                this.Lab_Q1.Text = sqlDataReader["Question1"].ToString();
                this.Lab_Q2.Text = sqlDataReader["Question2"].ToString();
                this.Lab_Q3.Text = sqlDataReader["Question3"].ToString();
            }
            else
            {
                MessageBox.Show("该身份证号未注册过该系统，是否输入错误");
            }
            sqlConnection.Close();
            

        }

        private void Btn_FindPassword_Click(object sender, EventArgs e)
        {
            SqlConnection sqlConnection = new SqlConnection();
            sqlConnection.ConnectionString =
                "Server=(local);Database=OutpatientSystem;Integrated Security=sspi";
            SqlCommand sqlCommand = new SqlCommand();
            sqlCommand.Connection = sqlConnection;
            sqlCommand.CommandText =
                $"SELECT COUNT(1) FROM tb_Authentication WHERE Answer1=@A1 AND Answer2=@A2 AND Answer3=@A3;";
            sqlCommand.Parameters.AddWithValue("@A1", this.Tex_Q1.Text.Trim());
            sqlCommand.Parameters.AddWithValue("@A2", this.Tex_Q2.Text.Trim());
            sqlCommand.Parameters.AddWithValue("@A3", this.Tex_Q3.Text.Trim());
            sqlConnection.Open();
            int rowCount = (int)sqlCommand.ExecuteScalar();
            sqlConnection.Close();
            if (rowCount == 1)
            {
                sqlCommand.CommandText =
                    $"SELECT Password FROM tb_User WHERE IDNumber='{this.Tex_IDNumber.Text.Trim()}';";
                sqlConnection.Open();
                string password = (string)sqlCommand.ExecuteScalar();
                sqlConnection.Close();
                Lab_Password.Text = password;
            }
            else
            {
                MessageBox.Show("身份验证失败，请重新查看是否回答正确");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SystemLogin systemLogin = new SystemLogin();
            systemLogin.Show();
        }

        private void FindPassword_Load(object sender, EventArgs e)
        {

        }
    }
}
