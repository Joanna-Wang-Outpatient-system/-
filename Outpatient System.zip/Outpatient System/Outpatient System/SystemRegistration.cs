﻿using System.Data;
using System;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Outpatient_System
{
    public partial class SystemRegistration : Form
    {
        public SystemRegistration()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void SystemRegistration_Load(object sender, EventArgs e)
        {

        }

        private void But_Registration_Click(object sender, EventArgs e)
        {
            SqlConnection sqlConnection = new SqlConnection();
            sqlConnection.ConnectionString =
                "Server=(local);Database=OutpatientSystem;Integrated Security=sspi";
            SqlCommand sqlCommand = sqlConnection.CreateCommand();
            if (this.Tex_UserName.Text.Trim() == "")
            {
                Lab_UserName.Text = "用户名不能为空！";
                this.Tex_UserName.Focus();
                return;
            }
            else
            {
                sqlCommand.CommandText =
                    $"SELECT COUNT(1) FROM tb_User WHERE UserNumber='{this.Tex_UserName.Text.Trim()}';";
                sqlConnection.Open();
                int rowCount1 = (int)sqlCommand.ExecuteScalar();
                sqlConnection.Close();
                if (rowCount1 == 1)
                {
                    Lab_UserName.Text = "该用户名已被使用";
                    return;
                }
                else
                {
                    Lab_UserName.Text = " ";
                }
                
            }
            if (this.Tex_Name.Text.Trim() == "")
            {
                Lab_Name.Text = "姓名不能为空！";
                this.Tex_Name.Focus();
                return;
            }
            else
            {
                Lab_Name.Text = " ";
            }
            if (this.Tex_Password.Text.Trim() == "")
            {
                Lab_Password.Text = "密码不能为空！";
                this.Tex_UserName.Focus();
                return;
            }
            else
            {
                Lab_Password.Text = "  ";
            }
            if (this.Tex_IDnumber.Text.Trim() == "")
            {
                Lab_IDNumber.Text = "身份证号不能为空！";
                this.Tex_IDnumber.Focus();
                return;
            }
            else
            {
                sqlCommand.CommandText =
                    $"SELECT COUNT(1) FROM tb_EveryoneID WHERE Name='{this.Tex_Name.Text.Trim()}' AND IDNumber='{this.Tex_IDnumber.Text.Trim()}';";
                sqlConnection.Open();
                int rowCount2 = (int)sqlCommand.ExecuteScalar();
                sqlConnection.Close();
                if (rowCount2 != 1)
                {
                    Lab_IDNumber.Text = "身份证号错误！请重新输入！";
                    return;
                }
                else
                {
                    Lab_IDNumber.Text = " ";
                }
                sqlCommand.CommandText =
                    $"SELECT COUNT(1) FROM tb_User WHERE IDnumber='{this.Tex_IDnumber.Text.Trim()}';";
                sqlConnection.Open();
                int rowCount3 = (int)sqlCommand.ExecuteScalar();
                sqlConnection.Close();
                if (rowCount3 == 1)
                {
                    Lab_IDNumber.Text = "该身份证号已被注册！";
                    return;
                }
                else
                {
                    Lab_IDNumber.Text = " ";
                }
            }
            if (this.Tex_Email.Text.Trim() == "")
            {
                Lab_Email.Text = "邮箱不能为空！";
                this.Tex_Email.Focus();
            }
            else
            {
                Lab_Email.Text = " ";
            }
            sqlCommand.CommandText =
                "INSERT tb_User (UserNumber,Password,IDnumber,Email) VALUES(@No,HASHBYTES('MD5',@Password),@IDNumber,@Email);";
            sqlCommand.Parameters.AddWithValue("@No", this.Tex_UserName.Text.Trim());
            sqlCommand.Parameters.AddWithValue("@Password", this.Tex_Password.Text.Trim());
            sqlCommand.Parameters["@Password"].SqlDbType = SqlDbType.VarChar;
            sqlCommand.Parameters.AddWithValue("@IDNumber", this.Tex_IDnumber.Text.Trim());
            sqlCommand.Parameters.AddWithValue("@Email", this.Tex_Email.Text.Trim());
            int rowAffected = 0;
            try
            {
                sqlConnection.Open();
                rowAffected = sqlCommand.ExecuteNonQuery();
            }
            catch(SqlException sqlEx)
            {
                if (sqlEx.Number == 2627)
                {
                    MessageBox.Show("您已经完成注册，请勿重复注册！");
                }
                else
                {
                    MessageBox.Show("注册失败！请联系管理员！");
                }
            }
            finally
            {
                sqlConnection.Close();
            }
            if (rowAffected == 1)
            {
                MessageBox.Show("注册成功。");
            }
            else
            {
                MessageBox.Show("注册失败。");
            }
        }
    }
}
