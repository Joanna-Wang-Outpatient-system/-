﻿using System.Data;
using System;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Outpatient_System
{
    public partial class FindUserNumber : Form
    {
        public FindUserNumber()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void But_Find_Click(object sender, EventArgs e)
        {
            SqlConnection sqlConnection = new SqlConnection();
            sqlConnection.ConnectionString =
                "Server=(local);Database=OutpatientSystem;Integrated Security=sspi";
            SqlCommand sqlCommand = new SqlCommand();
            sqlCommand.Connection = sqlConnection;
            sqlCommand.CommandText =
                $"SELECT COUNT(1) FROM tb_User WHERE IDNumber=@IDNumber; ";
            sqlCommand.Parameters.AddWithValue("@IDNumber", this.Tex_IDNumber.Text.Trim());
            sqlConnection.Open();
            int rowCount = (int)sqlCommand.ExecuteScalar();
            sqlConnection.Close();
            if (rowCount == 1)
            {
                sqlCommand.CommandText =
                    $"SELECT UserNumber FROM tb_User WHERE IDNumber='{this.Tex_IDNumber.Text.Trim()}';";
                sqlConnection.Open();
                string username = (string)sqlCommand.ExecuteScalar();
                sqlConnection.Close();
                Lab_UserName.Text = username; 
            }
            else
            {
                MessageBox.Show("该身份证号未注册过该系统，是否输入错误");
            }
        }

        private void FindUserNumber_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SystemLogin systemLogin = new SystemLogin();
            systemLogin.Show();
        }
    }
}
