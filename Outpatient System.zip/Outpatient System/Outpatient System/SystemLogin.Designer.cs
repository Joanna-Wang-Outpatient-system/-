﻿namespace Outpatient_System
{
    partial class SystemLogin
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SystemLogin));
            this.Tex_UserName = new System.Windows.Forms.TextBox();
            this.Tex_Password = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.But_Denglu = new System.Windows.Forms.Button();
            this.Btu_Zhuce = new System.Windows.Forms.Button();
            this.But_FindUserName = new System.Windows.Forms.Button();
            this.But_FindPassword = new System.Windows.Forms.Button();
            this.Lab_UserName = new System.Windows.Forms.Label();
            this.Lab_Password = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Tex_UserName
            // 
            this.Tex_UserName.Location = new System.Drawing.Point(219, 138);
            this.Tex_UserName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Tex_UserName.Name = "Tex_UserName";
            this.Tex_UserName.Size = new System.Drawing.Size(177, 25);
            this.Tex_UserName.TabIndex = 0;
            this.Tex_UserName.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Tex_Password
            // 
            this.Tex_Password.Location = new System.Drawing.Point(219, 208);
            this.Tex_Password.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Tex_Password.Name = "Tex_Password";
            this.Tex_Password.Size = new System.Drawing.Size(177, 25);
            this.Tex_Password.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(111, 142);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "用户名：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Control;
            this.label2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(132, 212);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "密码：";
            // 
            // But_Denglu
            // 
            this.But_Denglu.BackColor = System.Drawing.Color.Transparent;
            this.But_Denglu.Location = new System.Drawing.Point(115, 312);
            this.But_Denglu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.But_Denglu.Name = "But_Denglu";
            this.But_Denglu.Size = new System.Drawing.Size(75, 22);
            this.But_Denglu.TabIndex = 4;
            this.But_Denglu.Text = "登录";
            this.But_Denglu.UseVisualStyleBackColor = false;
            this.But_Denglu.Click += new System.EventHandler(this.But_Denglu_Click);
            // 
            // Btu_Zhuce
            // 
            this.Btu_Zhuce.Location = new System.Drawing.Point(337, 312);
            this.Btu_Zhuce.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Btu_Zhuce.Name = "Btu_Zhuce";
            this.Btu_Zhuce.Size = new System.Drawing.Size(75, 22);
            this.Btu_Zhuce.TabIndex = 5;
            this.Btu_Zhuce.Text = "注册";
            this.Btu_Zhuce.UseVisualStyleBackColor = true;
            this.Btu_Zhuce.Click += new System.EventHandler(this.Btu_Zhuce_Click);
            // 
            // But_FindUserName
            // 
            this.But_FindUserName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.But_FindUserName.ForeColor = System.Drawing.Color.Red;
            this.But_FindUserName.Location = new System.Drawing.Point(12, 386);
            this.But_FindUserName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.But_FindUserName.Name = "But_FindUserName";
            this.But_FindUserName.Size = new System.Drawing.Size(504, 22);
            this.But_FindUserName.TabIndex = 6;
            this.But_FindUserName.Text = "找回用户名";
            this.But_FindUserName.UseVisualStyleBackColor = false;
            this.But_FindUserName.Click += new System.EventHandler(this.But_FindUserName_Click);
            // 
            // But_FindPassword
            // 
            this.But_FindPassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.But_FindPassword.ForeColor = System.Drawing.Color.Red;
            this.But_FindPassword.Location = new System.Drawing.Point(12, 405);
            this.But_FindPassword.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.But_FindPassword.Name = "But_FindPassword";
            this.But_FindPassword.Size = new System.Drawing.Size(504, 22);
            this.But_FindPassword.TabIndex = 7;
            this.But_FindPassword.Text = "找回密码";
            this.But_FindPassword.UseVisualStyleBackColor = false;
            this.But_FindPassword.Click += new System.EventHandler(this.But_FindPassword_Click);
            // 
            // Lab_UserName
            // 
            this.Lab_UserName.AutoSize = true;
            this.Lab_UserName.BackColor = System.Drawing.Color.Transparent;
            this.Lab_UserName.ForeColor = System.Drawing.Color.Red;
            this.Lab_UserName.Location = new System.Drawing.Point(427, 146);
            this.Lab_UserName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lab_UserName.Name = "Lab_UserName";
            this.Lab_UserName.Size = new System.Drawing.Size(15, 15);
            this.Lab_UserName.TabIndex = 8;
            this.Lab_UserName.Text = " ";
            // 
            // Lab_Password
            // 
            this.Lab_Password.AutoSize = true;
            this.Lab_Password.BackColor = System.Drawing.Color.Transparent;
            this.Lab_Password.ForeColor = System.Drawing.Color.Red;
            this.Lab_Password.Location = new System.Drawing.Point(427, 211);
            this.Lab_Password.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lab_Password.Name = "Lab_Password";
            this.Lab_Password.Size = new System.Drawing.Size(15, 15);
            this.Lab_Password.TabIndex = 9;
            this.Lab_Password.Text = " ";
            // 
            // SystemLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(528, 440);
            this.Controls.Add(this.Lab_Password);
            this.Controls.Add(this.Lab_UserName);
            this.Controls.Add(this.But_FindPassword);
            this.Controls.Add(this.But_FindUserName);
            this.Controls.Add(this.Btu_Zhuce);
            this.Controls.Add(this.But_Denglu);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Tex_Password);
            this.Controls.Add(this.Tex_UserName);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "SystemLogin";
            this.Text = "登录";
            this.Load += new System.EventHandler(this.SystemLogin_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Tex_UserName;
        private System.Windows.Forms.TextBox Tex_Password;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button But_Denglu;
        private System.Windows.Forms.Button Btu_Zhuce;
        private System.Windows.Forms.Button But_FindUserName;
        private System.Windows.Forms.Button But_FindPassword;
        private System.Windows.Forms.Label Lab_UserName;
        private System.Windows.Forms.Label Lab_Password;
    }
}

