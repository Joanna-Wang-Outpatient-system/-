﻿namespace Outpatient_System
{
    partial class SystemRegistration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SystemRegistration));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Tex_UserName = new System.Windows.Forms.TextBox();
            this.Tex_Password = new System.Windows.Forms.TextBox();
            this.Tex_IDnumber = new System.Windows.Forms.TextBox();
            this.Tex_Email = new System.Windows.Forms.TextBox();
            this.But_Registration = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.Tex_Name = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Lab_UserName = new System.Windows.Forms.Label();
            this.Lab_Name = new System.Windows.Forms.Label();
            this.Lab_Password = new System.Windows.Forms.Label();
            this.Lab_IDNumber = new System.Windows.Forms.Label();
            this.Lab_Email = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(13, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(151, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "请设置一个用户名：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(70, 175);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "密码：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(40, 217);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "身份证号：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(55, 259);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "邮箱号：";
            // 
            // Tex_UserName
            // 
            this.Tex_UserName.Location = new System.Drawing.Point(161, 86);
            this.Tex_UserName.Name = "Tex_UserName";
            this.Tex_UserName.Size = new System.Drawing.Size(161, 25);
            this.Tex_UserName.TabIndex = 5;
            // 
            // Tex_Password
            // 
            this.Tex_Password.Location = new System.Drawing.Point(161, 172);
            this.Tex_Password.Name = "Tex_Password";
            this.Tex_Password.Size = new System.Drawing.Size(161, 25);
            this.Tex_Password.TabIndex = 6;
            // 
            // Tex_IDnumber
            // 
            this.Tex_IDnumber.Location = new System.Drawing.Point(161, 214);
            this.Tex_IDnumber.Name = "Tex_IDnumber";
            this.Tex_IDnumber.Size = new System.Drawing.Size(161, 25);
            this.Tex_IDnumber.TabIndex = 8;
            // 
            // Tex_Email
            // 
            this.Tex_Email.Location = new System.Drawing.Point(161, 256);
            this.Tex_Email.Name = "Tex_Email";
            this.Tex_Email.Size = new System.Drawing.Size(161, 25);
            this.Tex_Email.TabIndex = 9;
            // 
            // But_Registration
            // 
            this.But_Registration.Location = new System.Drawing.Point(146, 319);
            this.But_Registration.Name = "But_Registration";
            this.But_Registration.Size = new System.Drawing.Size(75, 23);
            this.But_Registration.TabIndex = 10;
            this.But_Registration.Text = "注册";
            this.But_Registration.UseVisualStyleBackColor = true;
            this.But_Registration.Click += new System.EventHandler(this.But_Registration_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(40, 131);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 15);
            this.label3.TabIndex = 11;
            this.label3.Text = "您的姓名：";
            // 
            // Tex_Name
            // 
            this.Tex_Name.Location = new System.Drawing.Point(161, 128);
            this.Tex_Name.Name = "Tex_Name";
            this.Tex_Name.Size = new System.Drawing.Size(161, 25);
            this.Tex_Name.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(13, 361);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(352, 15);
            this.label6.TabIndex = 13;
            this.label6.Text = "密码设置通常建议使用三种以上的字符以确保安全性";
            // 
            // Lab_UserName
            // 
            this.Lab_UserName.AutoSize = true;
            this.Lab_UserName.BackColor = System.Drawing.Color.Transparent;
            this.Lab_UserName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Lab_UserName.Location = new System.Drawing.Point(342, 89);
            this.Lab_UserName.Name = "Lab_UserName";
            this.Lab_UserName.Size = new System.Drawing.Size(15, 15);
            this.Lab_UserName.TabIndex = 14;
            this.Lab_UserName.Text = " ";
            // 
            // Lab_Name
            // 
            this.Lab_Name.AutoSize = true;
            this.Lab_Name.BackColor = System.Drawing.Color.Transparent;
            this.Lab_Name.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Lab_Name.Location = new System.Drawing.Point(342, 131);
            this.Lab_Name.Name = "Lab_Name";
            this.Lab_Name.Size = new System.Drawing.Size(15, 15);
            this.Lab_Name.TabIndex = 15;
            this.Lab_Name.Text = " ";
            // 
            // Lab_Password
            // 
            this.Lab_Password.AutoSize = true;
            this.Lab_Password.BackColor = System.Drawing.Color.Transparent;
            this.Lab_Password.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Lab_Password.Location = new System.Drawing.Point(342, 175);
            this.Lab_Password.Name = "Lab_Password";
            this.Lab_Password.Size = new System.Drawing.Size(15, 15);
            this.Lab_Password.TabIndex = 16;
            this.Lab_Password.Text = " ";
            // 
            // Lab_IDNumber
            // 
            this.Lab_IDNumber.AutoSize = true;
            this.Lab_IDNumber.BackColor = System.Drawing.Color.Transparent;
            this.Lab_IDNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Lab_IDNumber.Location = new System.Drawing.Point(342, 217);
            this.Lab_IDNumber.Name = "Lab_IDNumber";
            this.Lab_IDNumber.Size = new System.Drawing.Size(15, 15);
            this.Lab_IDNumber.TabIndex = 17;
            this.Lab_IDNumber.Text = " ";
            // 
            // Lab_Email
            // 
            this.Lab_Email.AutoSize = true;
            this.Lab_Email.BackColor = System.Drawing.Color.Transparent;
            this.Lab_Email.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Lab_Email.Location = new System.Drawing.Point(342, 259);
            this.Lab_Email.Name = "Lab_Email";
            this.Lab_Email.Size = new System.Drawing.Size(15, 15);
            this.Lab_Email.TabIndex = 18;
            this.Lab_Email.Text = " ";
            // 
            // SystemRegistration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(593, 403);
            this.Controls.Add(this.Lab_Email);
            this.Controls.Add(this.Lab_IDNumber);
            this.Controls.Add(this.Lab_Password);
            this.Controls.Add(this.Lab_Name);
            this.Controls.Add(this.Lab_UserName);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Tex_Name);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.But_Registration);
            this.Controls.Add(this.Tex_Email);
            this.Controls.Add(this.Tex_IDnumber);
            this.Controls.Add(this.Tex_Password);
            this.Controls.Add(this.Tex_UserName);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "SystemRegistration";
            this.Text = "注册";
            this.Load += new System.EventHandler(this.SystemRegistration_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Tex_UserName;
        private System.Windows.Forms.TextBox Tex_Password;
        private System.Windows.Forms.TextBox Tex_IDnumber;
        private System.Windows.Forms.TextBox Tex_Email;
        private System.Windows.Forms.Button But_Registration;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Tex_Name;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label Lab_UserName;
        private System.Windows.Forms.Label Lab_Name;
        private System.Windows.Forms.Label Lab_Password;
        private System.Windows.Forms.Label Lab_IDNumber;
        private System.Windows.Forms.Label Lab_Email;
    }
}