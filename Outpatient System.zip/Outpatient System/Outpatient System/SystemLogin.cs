﻿using System.Data;
using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;


namespace Outpatient_System
{
    public partial class SystemLogin : Form
    {
        public SystemLogin()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void SystemLogin_Load(object sender, EventArgs e)
        {

        }

        private void But_Denglu_Click(object sender, EventArgs e)
        {
            if (this.Tex_UserName.Text.Trim() == "")
            {
                Lab_UserName.Text = "用户名不能为空！";
                this.Tex_UserName.Focus();
                return;
            }
            if (this.Tex_Password.Text.Trim() == "")
            {
                Lab_Password.Text = "密码不能为空！";
                this.Tex_Password.Focus();
                return;
            }
            SqlConnection sqlConnection = new SqlConnection();
            sqlConnection.ConnectionString =
                "Server=(local);Database=OutpatientSystem;Integrated Security=sspi";
            SqlCommand sqlCommand = new SqlCommand();
            sqlCommand.Connection = sqlConnection;
            sqlCommand.CommandText =
                $"SELECT COUNT(1) FROM tb_User WHERE UserNumber=@No AND Password =HASHBYTES('MD5', @Password); ";
            sqlCommand.Parameters.AddWithValue("@No", this.Tex_UserName.Text.Trim());
            //SqlParameter sqlParameter= new SqlParameter();
            //sqlParameter.ParameterName = "@password";
            //sqlParameter.Value = this.Tex_Password.Text.Trim();
            //sqlParameter.SqlDbType = SqlDbType.VarChar;
            //sqlParameter.Size = 10;
            //sqlCommand.Parameters.Add(sqlParameter);
            sqlCommand.Parameters.AddWithValue("@Password", this.Tex_Password.Text.Trim());
            sqlCommand.Parameters["@Password"].SqlDbType = SqlDbType.VarChar;
            sqlConnection.Open();
            int rowCount = (int)sqlCommand.ExecuteScalar();
            sqlConnection.Close();
            
            if (rowCount == 1)
            {
                MessageBox.Show("登陆成功！");
                Homepage hompage = new Homepage();
                hompage.Show();
            }
            else
            {
                MessageBox.Show("用户名/密码错误！请重新输入！");
                this.Tex_Password.Focus();
                this.Tex_Password.SelectAll();
            }
           

        }

        private void But_FindUserName_Click(object sender, EventArgs e)
        {
            FindUserNumber findUserNumber = new FindUserNumber();
            findUserNumber.Show();
        }

        private void But_FindPassword_Click(object sender, EventArgs e)
        {
            FindPassword findPassword = new FindPassword();
            findPassword.Show();
        }

        private void Btu_Zhuce_Click(object sender, EventArgs e)
        {
            SystemRegistration systemRegistration = new SystemRegistration();
            systemRegistration.Show();
        }
    }
}
