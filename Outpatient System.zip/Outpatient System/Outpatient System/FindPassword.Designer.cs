﻿namespace Outpatient_System
{
    partial class FindPassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FindPassword));
            this.label1 = new System.Windows.Forms.Label();
            this.Tex_IDNumber = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Tex_Q3 = new System.Windows.Forms.TextBox();
            this.Lab_Q3 = new System.Windows.Forms.Label();
            this.Tex_Q2 = new System.Windows.Forms.TextBox();
            this.Lab_Q2 = new System.Windows.Forms.Label();
            this.Tex_Q1 = new System.Windows.Forms.TextBox();
            this.Lab_Q1 = new System.Windows.Forms.Label();
            this.Btn_Authentication = new System.Windows.Forms.Button();
            this.Btn_FindPassword = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.Lab_Password = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(107, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "请输入您的身份证号：";
            // 
            // Tex_IDNumber
            // 
            this.Tex_IDNumber.Location = new System.Drawing.Point(289, 34);
            this.Tex_IDNumber.Name = "Tex_IDNumber";
            this.Tex_IDNumber.Size = new System.Drawing.Size(271, 25);
            this.Tex_IDNumber.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(12, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "请回答以下问题";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.Tex_Q3);
            this.groupBox1.Controls.Add(this.Lab_Q3);
            this.groupBox1.Controls.Add(this.Tex_Q2);
            this.groupBox1.Controls.Add(this.Lab_Q2);
            this.groupBox1.Controls.Add(this.Tex_Q1);
            this.groupBox1.Controls.Add(this.Lab_Q1);
            this.groupBox1.Location = new System.Drawing.Point(12, 120);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(776, 283);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "身份验证";
            // 
            // Tex_Q3
            // 
            this.Tex_Q3.Location = new System.Drawing.Point(43, 233);
            this.Tex_Q3.Name = "Tex_Q3";
            this.Tex_Q3.Size = new System.Drawing.Size(687, 25);
            this.Tex_Q3.TabIndex = 5;
            // 
            // Lab_Q3
            // 
            this.Lab_Q3.AutoSize = true;
            this.Lab_Q3.Location = new System.Drawing.Point(40, 198);
            this.Lab_Q3.Name = "Lab_Q3";
            this.Lab_Q3.Size = new System.Drawing.Size(31, 15);
            this.Lab_Q3.TabIndex = 4;
            this.Lab_Q3.Text = "***";
            // 
            // Tex_Q2
            // 
            this.Tex_Q2.Location = new System.Drawing.Point(43, 153);
            this.Tex_Q2.Name = "Tex_Q2";
            this.Tex_Q2.Size = new System.Drawing.Size(687, 25);
            this.Tex_Q2.TabIndex = 3;
            // 
            // Lab_Q2
            // 
            this.Lab_Q2.AutoSize = true;
            this.Lab_Q2.Location = new System.Drawing.Point(40, 115);
            this.Lab_Q2.Name = "Lab_Q2";
            this.Lab_Q2.Size = new System.Drawing.Size(31, 15);
            this.Lab_Q2.TabIndex = 2;
            this.Lab_Q2.Text = "***";
            // 
            // Tex_Q1
            // 
            this.Tex_Q1.Location = new System.Drawing.Point(43, 69);
            this.Tex_Q1.Name = "Tex_Q1";
            this.Tex_Q1.Size = new System.Drawing.Size(687, 25);
            this.Tex_Q1.TabIndex = 1;
            // 
            // Lab_Q1
            // 
            this.Lab_Q1.AutoSize = true;
            this.Lab_Q1.Location = new System.Drawing.Point(40, 37);
            this.Lab_Q1.Name = "Lab_Q1";
            this.Lab_Q1.Size = new System.Drawing.Size(31, 15);
            this.Lab_Q1.TabIndex = 0;
            this.Lab_Q1.Text = "***";
            // 
            // Btn_Authentication
            // 
            this.Btn_Authentication.Location = new System.Drawing.Point(630, 37);
            this.Btn_Authentication.Name = "Btn_Authentication";
            this.Btn_Authentication.Size = new System.Drawing.Size(112, 23);
            this.Btn_Authentication.TabIndex = 4;
            this.Btn_Authentication.Text = "身份验证";
            this.Btn_Authentication.UseVisualStyleBackColor = true;
            this.Btn_Authentication.Click += new System.EventHandler(this.Btn_Authentication_Click);
            // 
            // Btn_FindPassword
            // 
            this.Btn_FindPassword.BackColor = System.Drawing.Color.White;
            this.Btn_FindPassword.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Btn_FindPassword.Location = new System.Drawing.Point(794, 235);
            this.Btn_FindPassword.Name = "Btn_FindPassword";
            this.Btn_FindPassword.Size = new System.Drawing.Size(139, 69);
            this.Btn_FindPassword.TabIndex = 5;
            this.Btn_FindPassword.Text = "找回密码";
            this.Btn_FindPassword.UseVisualStyleBackColor = false;
            this.Btn_FindPassword.Click += new System.EventHandler(this.Btn_FindPassword_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(164, 443);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(135, 20);
            this.label6.TabIndex = 6;
            this.label6.Text = "您的密码为：";
            // 
            // Lab_Password
            // 
            this.Lab_Password.AutoSize = true;
            this.Lab_Password.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Lab_Password.Location = new System.Drawing.Point(378, 443);
            this.Lab_Password.Name = "Lab_Password";
            this.Lab_Password.Size = new System.Drawing.Size(42, 20);
            this.Lab_Password.TabIndex = 7;
            this.Lab_Password.Text = "***";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(165, 475);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(337, 15);
            this.label8.TabIndex = 8;
            this.label8.Text = "请记清密码，若想修改密码请到系统内部进行修改";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(713, 443);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 9;
            this.button1.Text = "返回登录";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FindPassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(945, 499);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Lab_Password);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Btn_FindPassword);
            this.Controls.Add(this.Btn_Authentication);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Tex_IDNumber);
            this.Controls.Add(this.label1);
            this.Name = "FindPassword";
            this.Text = "找回密码";
            this.Load += new System.EventHandler(this.FindPassword_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Tex_IDNumber;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox Tex_Q3;
        private System.Windows.Forms.Label Lab_Q3;
        private System.Windows.Forms.TextBox Tex_Q2;
        private System.Windows.Forms.Label Lab_Q2;
        private System.Windows.Forms.TextBox Tex_Q1;
        private System.Windows.Forms.Label Lab_Q1;
        private System.Windows.Forms.Button Btn_Authentication;
        private System.Windows.Forms.Button Btn_FindPassword;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label Lab_Password;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button1;
    }
}